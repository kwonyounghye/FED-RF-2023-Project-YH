// 이미지 경로 정보
export const img = {
    // 각 서브페이지 이미지 경로
    "logo": ["./images/logo.png"],
    "main": [
        "./images/main1.jpg",
        "./images/main2.jpg",
        "./images/main3.jpg",
    ],
    "introduce": [
        "./images/intro1.jpg",
        "./images/intro2.jpg",
        "./images/intro3.jpg",
    ],
    "menuImg": [
        "./images/menu1.jpg",
        "./images/menu2.jpg", 
        "./images/menu3.jpg",
        "./images/menu4.jpg",
        "./images/menu5.jpg"
    ],
}