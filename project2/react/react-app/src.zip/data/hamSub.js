// GNB 페이지별 메뉴 데이터??
export const hamSub = {
    "main":["ABOUT","MENU","CONTACT"],
    "about":[],
    "menu":[],
    "contact":[]
}; //////////// hamSub //////////////////