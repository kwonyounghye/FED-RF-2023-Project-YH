// : 뒤에 괄호를 쓰면 []
// : 앞에서부터 감싸면 {}
export const menu = {
    menu1: {
        name: "stollen",
        img: "./images/menu1.jpg",
    },
    menu2: {
        name: "Salt bread",
        img: "./images/menu2.jpg",
    },
    menu3: {
        name: "Canulet",
        img: "./images/menu3.jpg",
    },
    menu4: {
        name: "Leven Cookies",
        img: "./images/menu4.jpg",
    },
    menu5: {
        name: "mini cookie",
        img: "./images/menu5.jpg",
    },
}