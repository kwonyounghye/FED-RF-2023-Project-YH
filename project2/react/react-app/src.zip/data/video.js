export const video = 
  {'main':'./images/tree.mp4'}