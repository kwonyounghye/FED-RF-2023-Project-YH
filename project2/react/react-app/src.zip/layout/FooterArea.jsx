// 하단영역 컴포넌트

export function FooterArea() {
    return (
        <footer></footer>
    )
}