import { Video } from "../modules/Video";

export function Main() {
    return (
        <>
            <Video vsrc="main" />
        </>
    )
}