import { createContext } from "react";

// props를 이용해 아래 있는 것들을 다 끌어온다.
// router는 주소 
export const yhCon = createContext();