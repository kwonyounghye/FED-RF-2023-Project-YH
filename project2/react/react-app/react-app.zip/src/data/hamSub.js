// GNB 페이지별 메뉴 데이터??
export const hamSub = {
    "main":["ABOUT","MENU","CONTACT"],
    "about":['../../public/images/intro3.jpg'],
    "menu":['../../public/images/menu8.jpg'],
    "contact":['../../public/images/main4.jpg']
}; //////////// hamSub //////////////////